#include "Database.h"
#include <stdexcept>
#include <iostream>

Database::Database(const std::string& connection_string)
    : conn_(connection_string)
{
    if (!conn_.is_open()) {
        throw std::runtime_error("No se pudo abrir la conexión a PostgreSQL");
    }
    std::cout << "[DB] Conectado a: " << conn_.dbname() << "\n";
}

pqxx::connection& Database::connection() {
    return conn_;
}

bool Database::isConnected() const {
    return conn_.is_open();
}
