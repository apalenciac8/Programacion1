#pragma once
#include "Database.h"
#include "User.h"
#include <vector>
#include <optional>

// Capa de acceso a datos para la tabla "usuarios".
// Todas las operaciones son transaccionales.
class UserRepository {
public:
    explicit UserRepository(Database& db);

    // Crea la tabla si no existe
    void createTableIfNotExists();

    // Inserta un usuario y devuelve el ID generado
    int  create(const std::string& nombre, const std::string& email);

    // Devuelve todos los usuarios
    std::vector<User> findAll();

    // Busca por ID (retorna vacío si no existe)
    std::optional<User> findById(int id);

    // Actualiza nombre y email; devuelve true si encontró el registro
    bool update(int id, const std::string& nombre, const std::string& email);

    // Elimina por ID; devuelve true si encontró el registro
    bool remove(int id);

private:
    Database& db_;
};
