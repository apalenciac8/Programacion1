#pragma once
#include <string>
#include <optional>

// Modelo que representa un usuario en la base de datos
struct User {
    int         id;
    std::string nombre;
    std::string email;
    std::string created_at;   // guardado como texto ISO desde PostgreSQL
};
