-- Ejecutar como superusuario de PostgreSQL
-- psql -U postgres -f sql/setup.sql

-- 1. Crear la base de datos (omitir si ya existe)
CREATE DATABASE demo_db
    WITH ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE   = 'en_US.UTF-8';

-- 2. Conectar a ella
\connect demo_db

-- 3. La tabla se crea automáticamente desde C++ con createTableIfNotExists(),
--    pero también puedes crearla aquí manualmente:
CREATE TABLE IF NOT EXISTS usuarios (
    id         SERIAL PRIMARY KEY,
    nombre     VARCHAR(100) NOT NULL,
    email      VARCHAR(150) UNIQUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Datos de prueba opcionales
INSERT INTO usuarios (nombre, email) VALUES
    ('Admin Demo', 'admin@demo.com')
ON CONFLICT (email) DO NOTHING;
